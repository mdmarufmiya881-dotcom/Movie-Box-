import React, { useState } from 'react';
import { 
  Activity, 
  Film, 
  Tv, 
  Calendar, 
  Code, 
  MessageSquare, 
  Users, 
  Award, 
  CreditCard, 
  Settings, 
  Menu, 
  X,
  Clapperboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Import Tab Components
import AnalyticsTab from './components/AnalyticsTab';
import MoviesTab from './components/MoviesTab';
import LiveTvTab from './components/LiveTvTab';
import UpcomingTab from './components/UpcomingTab';
import CodesTab from './components/CodesTab';
import MovieRequestsTab from './components/MovieRequestsTab';
import UsersTab from './components/UsersTab';
import SubscriptionsTab from './components/SubscriptionsTab';
import PaymentTab from './components/PaymentTab';
import MaintenanceTab from './components/MaintenanceTab';

type TabId = 
  | 'analytics' 
  | 'movies' 
  | 'livetv' 
  | 'upcoming' 
  | 'codes' 
  | 'requests' 
  | 'users' 
  | 'subscriptions' 
  | 'payment' 
  | 'maintenance';

interface TabItem {
  id: TabId;
  label: string;
  icon: React.ComponentType<any>;
  component: React.ComponentType<any>;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('analytics');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const tabs: TabItem[] = [
    { id: 'analytics', label: 'Analytics', icon: Activity, component: AnalyticsTab },
    { id: 'movies', label: 'Movies Catalog', icon: Film, component: MoviesTab },
    { id: 'livetv', label: 'Live TV Streams', icon: Tv, component: LiveTvTab },
    { id: 'upcoming', label: 'Upcoming Releases', icon: Calendar, component: UpcomingTab },
    { id: 'codes', label: "Developer's Code", icon: Code, component: CodesTab },
    { id: 'requests', label: 'Movie Requests', icon: MessageSquare, component: MovieRequestsTab },
    { id: 'users', label: 'Users Base', icon: Users, component: UsersTab },
    { id: 'subscriptions', label: 'Subscription Plans', icon: Award, component: SubscriptionsTab },
    { id: 'payment', label: 'Payment Details', icon: CreditCard, component: PaymentTab },
    { id: 'maintenance', label: 'Maintenance Control', icon: Settings, component: MaintenanceTab },
  ];

  const ActiveComponent = tabs.find(t => t.id === activeTab)?.component || AnalyticsTab;

  return (
    <div id="moviebox-admin-dashboard" className="min-h-screen bg-black text-gray-100 flex flex-col antialiased font-sans selection:bg-red-600 selection:text-white">
      
      {/* Upper Navigation Banner */}
      <header className="sticky top-0 z-40 bg-zinc-950 border-b border-zinc-900 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-600/10">
            <Clapperboard className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-wider text-white uppercase font-sans">Movie Box</h1>
            <p className="text-[10px] text-red-500 font-bold tracking-widest uppercase">Admin Terminal</p>
          </div>
        </div>

        {/* Mobile menu toggle */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-zinc-400 hover:text-white transition-colors"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </header>

      {/* Main Layout */}
      <div className="flex-1 flex flex-col lg:flex-row">
        
        {/* Navigation Drawer Sidebar */}
        <nav className={`
          lg:block lg:w-72 lg:shrink-0 bg-zinc-950/70 lg:bg-zinc-950/20 border-r border-zinc-950 lg:border-zinc-900 p-4 space-y-2
          ${mobileMenuOpen ? 'block fixed inset-x-0 top-[73px] bottom-0 z-35 overflow-y-auto backdrop-blur-md' : 'hidden'}
        `}>
          <div className="text-[10px] text-gray-500 font-bold px-3 uppercase tracking-widest mb-4">Control Categories</div>
          
          <div className="space-y-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-3.5 rounded-xl text-sm font-semibold tracking-wide transition-all duration-150 cursor-pointer ${
                    isActive 
                      ? 'bg-red-600/10 text-red-500 border border-red-500/20 shadow-md shadow-red-950/5' 
                      : 'text-gray-400 hover:text-white hover:bg-zinc-900 border border-transparent'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-red-500' : 'text-gray-400'}`} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Dynamic Content Display Slot */}
        <main className="flex-1 p-6 sm:p-8 lg:p-10 max-w-6xl mx-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              <ActiveComponent />
            </motion.div>
          </AnimatePresence>
        </main>

      </div>
    </div>
  );
}
