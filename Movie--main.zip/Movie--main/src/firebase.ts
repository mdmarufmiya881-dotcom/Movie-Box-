import { initializeApp } from 'firebase/app';
import { getDatabase, ref } from 'firebase/database';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyCS_JX2M37kpp79XQujrFINeuTIF5ZshJs",
  authDomain: "dream-top-82747.firebaseapp.com",
  databaseURL: "https://dream-top-82747-default-rtdb.firebaseio.com",
  projectId: "dream-top-82747",
  storageBucket: "dream-top-82747.firebasestorage.app",
  messagingSenderId: "108959230192",
  appId: "1:108959230192:web:e33f0d5cce376e91b37a35",
  measurementId: "G-CRFL6YYJH0"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);

// DB Reference paths
export const movieRef = ref(db, 'movie');
export const usersRef = ref(db, 'users');
export const paymentRef = ref(db, 'Payment');
export const maintenanceRef = ref(db, 'maintenance');
export const appDownloadRef = ref(db, 'appDownload');
export const tvWebRef = ref(db, 'tvWeb');
export const subscriptionsRef = ref(db, 'subscriptions');
export const statsRef = ref(db, 'stats');
export const requestRef = ref(db, 'MovieRequest');
export const upcomingMovieRef = ref(db, 'upcomingmovie');
export const codeRef = ref(db, 'code');
export const liveTvRef = ref(db, 'liveTv'); // Newly added node for Live TV Channels
