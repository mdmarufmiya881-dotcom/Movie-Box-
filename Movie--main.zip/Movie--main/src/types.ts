export interface Movie {
  key?: string;
  title: string;
  poster: string;
  backdrop: string;
  year: string;
  rating: string;
  storyline: string;
  access: 'FREE' | 'VIP';
  language: string;
  movieLink: string;
  screenshots: string[];
  category: 'Hollywood' | 'Bollywood' | 'South Indian';
  likeCount: number;
  viewCount: number;
  timestamp: number;
}

export interface UpcomingMovie {
  key?: string;
  title: string;
  poster: string;
  releaseDate: string;
  timestamp: number;
}

export interface DevCode {
  key?: string;
  name: string;
  icon: string;
  category: string;
  details: string;
  screenshots: string[];
  downloadLink: string;
  contactLink: string;
  timestamp: number;
}

export interface MovieRequest {
  key?: string;
  title: string;
  year?: string;
  language?: string;
  requestedBy?: string;
  timestamp: number;
}

export interface User {
  uid?: string;
  email: string;
  status: string;
  subscriptionExpiry?: string | null;
}

export interface SubscriptionPlan {
  name: string;
  price: number;
  duration: number;
  features: string;
}

export interface SubscriptionPlans {
  [key: string]: SubscriptionPlan;
}

export interface PaymentDetails {
  accountName: string;
  qrUrl: string;
}

export interface MaintenanceSettings {
  status: 'on' | 'off';
  notice: string;
  contactLink: string;
}

export interface AppDownload {
  link: string;
  version: string;
  status: 'on' | 'off';
}

export interface TvWeb {
  link: string;
  status: 'on' | 'off';
}

export interface LiveTvChannel {
  key?: string;
  name: string;
  logoUrl: string;
  category: string; // e.g. Sports, News, Movies, Kids, Entertainment
  streamUrl: string;
  access: 'FREE' | 'VIP';
  timestamp: number;
}
