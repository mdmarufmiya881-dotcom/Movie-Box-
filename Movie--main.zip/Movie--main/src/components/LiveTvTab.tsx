import React, { useEffect, useState } from 'react';
import { onValue, push, remove, update } from 'firebase/database';
import { liveTvRef } from '../firebase';
import { LiveTvChannel } from '../types';
import { Search, Plus, Trash2, Edit2, Tv, Check, X, Filter, Sliders, Image, Eye, Radio, ExternalLink, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function LiveTvTab() {
  const [channels, setChannels] = useState<LiveTvChannel[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [accessFilter, setAccessFilter] = useState<string>('all');
  
  // Forms & Modals
  const [showAddForm, setShowAddForm] = useState(false);
  const [newChannel, setNewChannel] = useState<Partial<LiveTvChannel>>({
    name: '',
    logoUrl: '',
    category: 'Sports',
    streamUrl: '',
    access: 'FREE'
  });

  // Edit State
  const [editingChannel, setEditingChannel] = useState<LiveTvChannel | null>(null);
  
  // Stream Preview State
  const [previewChannel, setPreviewChannel] = useState<LiveTvChannel | null>(null);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(liveTvRef, (snapshot) => {
      const list: LiveTvChannel[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          list.push({
            key: child.key || undefined,
            ...child.val()
          });
        });
      }
      list.reverse(); // Newest first
      setChannels(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannel.name || !newChannel.streamUrl) {
      alert('Channel Name and Stream Link/URL are required.');
      return;
    }

    const payload: Omit<LiveTvChannel, 'key'> = {
      name: newChannel.name,
      logoUrl: newChannel.logoUrl || '',
      category: newChannel.category || 'Sports',
      streamUrl: newChannel.streamUrl,
      access: newChannel.access || 'FREE',
      timestamp: Date.now()
    };

    push(liveTvRef, payload).then(() => {
      alert('Live TV channel successfully added to database!');
      setNewChannel({
        name: '',
        logoUrl: '',
        category: 'Sports',
        streamUrl: '',
        access: 'FREE'
      });
      setShowAddForm(false);
    }).catch(err => {
      alert('Error saving channel: ' + err.message);
    });
  };

  const handleUpdateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChannel || !editingChannel.key) return;

    const { key, ...cleanPayload } = editingChannel;

    update(liveTvRef, { [key]: { ...cleanPayload } }).then(() => {
      alert('Live TV channel item updated successfully!');
      setEditingChannel(null);
    }).catch(err => {
      alert('Error updating channel: ' + err.message);
    });
  };

  const handleDeleteChannel = (key: string, name: string) => {
    if (confirm(`Are you absolutely sure you want to delete "${name}" from Live TV streams? This action is irreversible.`)) {
      update(liveTvRef, { [key]: null }).then(() => {
        alert(`"${name}" has been deleted.`);
      }).catch(err => {
        alert('Error deleting: ' + err.message);
      });
    }
  };

  const filteredChannels = channels.filter(c => {
    const matchesSearch = (c.name || '').toLowerCase().includes(search.toLowerCase()) || 
                          (c.category || '').toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || c.category === categoryFilter;
    const matchesAccess = accessFilter === 'all' || c.access === accessFilter;
    return matchesSearch && matchesCategory && matchesAccess;
  });

  const liveTvCategories = ['Sports', 'News', 'Movies', 'Entertainment', 'Kids', 'Music', 'Documentaries', 'Others'];

  return (
    <div className="space-y-6">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Tv className="text-red-500 w-6 h-6 animate-pulse" /> Live TV Streams
          </h2>
          <p className="text-gray-400 text-sm mt-1">Configure, add, edit, and delete real-time IPTV broadcast streams for TV section.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-all shadow-lg shadow-red-600/10 text-sm"
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Close Panel' : 'Add Live TV'}
        </button>
      </div>

      {/* Add Live TV Form Section */}
      <AnimatePresence>
        {showAddForm && (
          <motion.form 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleAddChannel}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden"
          >
            <div className="space-y-4">
              <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                <Sliders className="w-4 h-4" /> Channel Identity
              </h3>
              
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Channel Name *</label>
                <input 
                  type="text" 
                  value={newChannel.name} 
                  onChange={e => setNewChannel({...newChannel, name: e.target.value})}
                  placeholder="e.g. ESPN HD, HBO Live, CNN World"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Channel Genre/Category</label>
                  <select 
                    value={newChannel.category} 
                    onChange={e => setNewChannel({...newChannel, category: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  >
                    {liveTvCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Access Tier</label>
                  <select 
                    value={newChannel.access} 
                    onChange={e => setNewChannel({...newChannel, access: e.target.value as any})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  >
                    <option value="FREE">FREE (All Users)</option>
                    <option value="VIP">VIP (Premium Subscribers)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Stream Logo/Icon URL</label>
                <input 
                  type="text" 
                  value={newChannel.logoUrl} 
                  onChange={e => setNewChannel({...newChannel, logoUrl: e.target.value})}
                  placeholder="https://example.com/logo.png"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                  <Radio className="w-4 h-4 text-red-500" /> Broadcast Stream Details
                </h3>

                <div className="mt-4">
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Stream M3U8/MP4/Embed Link *</label>
                  <input 
                    type="text" 
                    value={newChannel.streamUrl} 
                    onChange={e => setNewChannel({...newChannel, streamUrl: e.target.value})}
                    placeholder="https://server.com/live/stream.m3u8"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                    required
                  />
                  <small className="text-gray-500 mt-2 block leading-relaxed">
                    Provide the live streaming source. Compatible with direct HLS (.m3u8), MP4, or external embedded HTML iframe feeds.
                  </small>
                </div>

                {newChannel.logoUrl && (
                  <div className="mt-4 p-3 bg-zinc-950 rounded-xl border border-zinc-850 flex items-center gap-4">
                    <img 
                      src={newChannel.logoUrl} 
                      alt="Logo preview" 
                      className="w-12 h-12 rounded-lg object-contain bg-zinc-900 border border-zinc-800"
                      onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=100' }}
                    />
                    <div>
                      <div className="text-xs text-gray-400 font-semibold">Icon Visual Preview</div>
                      <div className="text-[10px] text-gray-500">Live preview of channel branding logo</div>
                    </div>
                  </div>
                )}
              </div>

              <button 
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md mt-6 cursor-pointer text-sm"
              >
                <Check className="w-5 h-5" /> Save Live TV Stream
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Filter and Search Bar */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input 
            type="text" 
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search TV channels by name or category..."
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl pl-10 pr-4 py-2.5 text-white text-sm outline-none transition-all"
          />
        </div>
        
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 text-xs text-gray-400 font-semibold uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5" /> Filter by:
          </div>
          <select 
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-red-600 transition-all shadow-inner"
          >
            <option value="all">All Genres</option>
            {liveTvCategories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select 
            value={accessFilter}
            onChange={e => setAccessFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-red-600 transition-all shadow-inner"
          >
            <option value="all">All Access</option>
            <option value="FREE">FREE</option>
            <option value="VIP">VIP</option>
          </select>
        </div>
      </div>

      {/* TV Channels Grid List */}
      {loading ? (
        <div className="text-center py-20 text-gray-400 text-sm font-medium">Loading live feeds...</div>
      ) : filteredChannels.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No live TV channels matching your query.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredChannels.map((channel) => (
            <div key={channel.key} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden group hover:border-zinc-700 transition-all flex flex-col justify-between">
              <div className="p-5 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-zinc-950 border border-zinc-850 p-2 flex items-center justify-center shrink-0 overflow-hidden relative group-hover:border-red-600/50 transition-colors">
                    <img 
                      src={channel.logoUrl || 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=100'} 
                      alt={channel.name}
                      className="w-full h-full object-contain"
                      onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=100' }}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="font-bold text-white text-base leading-snug group-hover:text-red-500 transition-colors truncate">{channel.name}</h4>
                    <span className="text-[10px] bg-red-950/40 text-red-400 border border-red-900/40 font-semibold px-2 py-0.5 rounded-full inline-block mt-1">
                      {channel.category}
                    </span>
                  </div>
                </div>

                <div className="space-y-1 bg-zinc-950 border border-zinc-850 p-3 rounded-xl font-mono text-[11px] text-gray-400 select-all overflow-x-auto whitespace-nowrap scrollbar-thin">
                  <div className="text-gray-500 font-semibold mb-0.5 text-[9px] uppercase">Stream Source URL:</div>
                  {channel.streamUrl}
                </div>

                <div className="flex items-center justify-between text-xs text-zinc-500 pt-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    channel.access === 'FREE' 
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}>
                    {channel.access}
                  </span>
                  
                  <span className="text-[10px] text-gray-500">
                    Added: {new Date(channel.timestamp).toLocaleDateString()}
                  </span>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-4 bg-zinc-900/60 border-t border-zinc-850 flex gap-2">
                <button 
                  onClick={() => setPreviewChannel(channel)}
                  className="bg-zinc-850 hover:bg-zinc-800 text-white p-2 rounded-xl border border-zinc-700 transition-all flex items-center justify-center"
                  title="Test Stream"
                >
                  <Play className="w-3.5 h-3.5 text-green-500 fill-green-500" />
                </button>
                <button 
                  onClick={() => setEditingChannel(channel)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-zinc-850 hover:bg-zinc-850 text-white text-xs font-semibold py-2 px-3 rounded-xl transition-all border border-zinc-700"
                >
                  <Edit2 className="w-3 h-3 text-red-500" /> Edit Channel
                </button>
                <button 
                  onClick={() => handleDeleteChannel(channel.key!, channel.name)}
                  className="bg-red-950/60 hover:bg-red-900 text-red-400 text-xs font-semibold p-2 rounded-xl transition-all border border-red-900/40"
                  title="Delete Channel"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Playback Preview Modal */}
      <AnimatePresence>
        {previewChannel && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative"
            >
              <div className="flex justify-between items-center p-4 border-b border-zinc-800">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse"></span>
                  <span className="font-bold text-white text-sm">Testing Live Broadcast: {previewChannel.name}</span>
                </div>
                <button onClick={() => setPreviewChannel(null)} className="text-gray-400 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Simple HTML embed frame or placeholder */}
              <div className="aspect-video w-full bg-black flex flex-col items-center justify-center text-center p-6 relative">
                {previewChannel.streamUrl.includes('youtube.com') || previewChannel.streamUrl.includes('youtu.be') ? (
                  <iframe 
                    src={previewChannel.streamUrl.replace('watch?v=', 'embed/')} 
                    title={previewChannel.name}
                    className="w-full h-full border-none"
                    allowFullScreen
                  />
                ) : (
                  <div className="space-y-4">
                    <div className="w-16 h-16 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center mx-auto text-red-500">
                      <Tv className="w-8 h-8 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm">IPTV Stream Payload Prepared</h4>
                      <p className="text-xs text-gray-400 max-w-sm mx-auto mt-1 leading-relaxed">
                        To play custom HLS streaming .m3u8 index manifests natively, make sure you configure standard video libraries on user device.
                      </p>
                    </div>
                    <a 
                      href={previewChannel.streamUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-semibold text-xs px-4 py-2 rounded-lg transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" /> Launch Stream Externally
                    </a>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit TV Channel Modal */}
      <AnimatePresence>
        {editingChannel && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Edit2 className="text-red-500 w-5 h-5" /> Edit Live TV Feed
                </h3>
                <button onClick={() => setEditingChannel(null)} className="text-gray-400 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateChannel} className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase">Channel Name</label>
                  <input 
                    type="text" 
                    value={editingChannel.name} 
                    onChange={e => setEditingChannel({...editingChannel, name: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase">Genre/Category</label>
                    <select 
                      value={editingChannel.category} 
                      onChange={e => setEditingChannel({...editingChannel, category: e.target.value})}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    >
                      {liveTvCategories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase">Access Tier</label>
                    <select 
                      value={editingChannel.access} 
                      onChange={e => setEditingChannel({...editingChannel, access: e.target.value as any})}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    >
                      <option value="FREE">FREE</option>
                      <option value="VIP">VIP</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase">Stream URL</label>
                  <input 
                    type="text" 
                    value={editingChannel.streamUrl} 
                    onChange={e => setEditingChannel({...editingChannel, streamUrl: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase">Logo Icon URL</label>
                  <input 
                    type="text" 
                    value={editingChannel.logoUrl || ''} 
                    onChange={e => setEditingChannel({...editingChannel, logoUrl: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    placeholder="https://example.com/logo.png"
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t border-zinc-800">
                  <button 
                    type="button" 
                    onClick={() => setEditingChannel(null)}
                    className="flex-1 bg-zinc-850 hover:bg-zinc-800 text-white font-semibold py-3 rounded-xl transition-all text-sm cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl transition-all text-sm cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
