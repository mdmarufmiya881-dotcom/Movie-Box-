import React, { useEffect, useState } from 'react';
import { onValue, set } from 'firebase/database';
import { paymentRef } from '../firebase';
import { PaymentDetails } from '../types';
import { CreditCard, CheckCircle } from 'lucide-react';

export default function PaymentTab() {

const [payment,setPayment]=useState<PaymentDetails>({
  bkash:'',
  nagad:''
});

const [loading,setLoading]=useState(true);


useEffect(()=>{

const unsubscribe=onValue(paymentRef,(snapshot)=>{

if(snapshot.exists()){

const val=snapshot.val();

setPayment({
 bkash: val.bkash || '',
 nagad: val.nagad || ''
});

}

setLoading(false);

});


return()=>unsubscribe();

},[]);



const handleSavePayment=(e:React.FormEvent)=>{

e.preventDefault();


set(paymentRef,{
 bkash:payment.bkash,
 nagad:payment.nagad
})
.then(()=>{

alert("bKash Nagad updated successfully!");

})
.catch(err=>{

alert(err.message);

});


};



if(loading){

return <div className="text-center py-20 text-gray-400">
Loading...
</div>

}



return (

<div className="space-y-6">


<h2 className="text-2xl font-bold text-white flex items-center gap-2">

<CreditCard className="text-red-500"/>

Payment Details

</h2>



<div className="grid lg:grid-cols-2 gap-8">


<form
onSubmit={handleSavePayment}
className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5"
>


<h3 className="text-white font-bold">
💳 bKash / Nagad Settings
</h3>



<div>

<label className="text-gray-400 text-sm">
bKash Number
</label>


<input

value={payment.bkash}

onChange={e=>setPayment({
...payment,
bkash:e.target.value
})}

placeholder="01XXXXXXXXX"

className="w-full bg-zinc-950 text-white p-3 rounded-xl mt-2"

/>

</div>




<div>

<label className="text-gray-400 text-sm">
Nagad Number
</label>


<input

value={payment.nagad}

onChange={e=>setPayment({
...payment,
nagad:e.target.value
})}

placeholder="01XXXXXXXXX"

className="w-full bg-zinc-950 text-white p-3 rounded-xl mt-2"

/>

</div>



<button

className="w-full bg-red-600 text-white font-bold py-3 rounded-xl"

>

<CheckCircle className="inline w-5 h-5 mr-2"/>

Update Payment

</button>


</form>




<div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">

<h3 className="text-white font-bold mb-5">
Current Payment
</h3>


<p className="text-pink-500 font-bold">
bKash
</p>

<p className="text-gray-300">
{payment.bkash || "Not Set"}
</p>



<p className="text-orange-500 font-bold mt-5">
Nagad
</p>

<p className="text-gray-300">
{payment.nagad || "Not Set"}
</p>


</div>


</div>

</div>

);

}