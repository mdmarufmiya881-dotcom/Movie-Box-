import React, { useEffect, useState } from 'react';
import { onValue, set } from 'firebase/database';
import { subscriptionsRef } from '../firebase';
import { SubscriptionPlans, SubscriptionPlan } from '../types';
import { Award, DollarSign, Calendar, ListChecks, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function SubscriptionsTab() {
  const [plans, setPlans] = useState<SubscriptionPlans>({
    gold: { name: 'Gold', price: 50, duration: 30, features: 'Access All Movies\nHD Quality\nWatch on 1 Device' },
    diamond: { name: 'Diamond', price: 100, duration: 90, features: 'All Gold Features\n4K Quality\nWatch on 2 Devices' },
    platinum: { name: 'Platinum', price: 250, duration: 180, features: 'All Diamond Features\nNo Ads\nPriority Support' },
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(subscriptionsRef, (snapshot) => {
      if (snapshot.exists()) {
        setPlans(snapshot.val());
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handlePlanChange = (key: string, field: keyof SubscriptionPlan, value: any) => {
    setPlans(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [field]: value
      }
    }));
  };

  const handleSavePlans = (e: React.FormEvent) => {
    e.preventDefault();
    set(subscriptionsRef, plans).then(() => {
      alert('Subscription tiers configuration saved successfully!');
    }).catch(err => {
      alert('Error saving plan configurations: ' + err.message);
    });
  };

  if (loading) {
    return (
      <div className="text-center py-20 text-gray-400 text-sm">Synchronizing plan tiers...</div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Award className="text-red-500 w-6 h-6" /> Subscription Tiers Setup
        </h2>
        <p className="text-gray-400 text-sm mt-1">Configure pricing packages, durations, and text lists of premium feature sets.</p>
      </div>

      <form onSubmit={handleSavePlans} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.keys(plans).map((key) => {
            const plan = plans[key];
            return (
              <div 
                key={key} 
                className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5 relative overflow-hidden"
              >
                {/* Decorative glow */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-red-600/5 rounded-full blur-2xl"></div>

                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-red-950/40 border border-red-900/30 flex items-center justify-center text-red-400 shrink-0">
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg capitalize">{plan.name} Package</h3>
                    <p className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold">Plan ID: {key}</p>
                  </div>
                </div>

                <div className="space-y-4 pt-2">
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider flex items-center gap-1">
                      <DollarSign className="w-3.5 h-3.5 text-red-500" /> Package Price (RS/-)
                    </label>
                    <input 
                      type="number" 
                      value={plan.price || 0} 
                      onChange={e => handlePlanChange(key, 'price', parseInt(e.target.value, 10) || 0)}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-2.5 text-white text-sm outline-none transition-all"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-red-500" /> Duration Interval (Days)
                    </label>
                    <input 
                      type="number" 
                      value={plan.duration || 0} 
                      onChange={e => handlePlanChange(key, 'duration', parseInt(e.target.value, 10) || 0)}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-2.5 text-white text-sm outline-none transition-all"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider flex items-center gap-1">
                      <ListChecks className="w-3.5 h-3.5 text-red-500" /> Package Features (one per line)
                    </label>
                    <textarea 
                      value={plan.features || ''} 
                      onChange={e => handlePlanChange(key, 'features', e.target.value)}
                      placeholder="e.g. Access All Movies&#10;Full Ultra HD Streaming&#10;Simultaneous screens"
                      rows={5}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all resize-none font-sans"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <button 
          type="submit"
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3.5 rounded-xl transition-all shadow-md cursor-pointer text-sm"
        >
          <CheckCircle className="w-4 h-4" /> Save Plan Configuration Metrics
        </button>
      </form>
    </div>
  );
}
