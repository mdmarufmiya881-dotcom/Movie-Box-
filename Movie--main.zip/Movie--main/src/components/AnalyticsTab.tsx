import React, { useEffect, useState } from 'react';
import { onValue } from 'firebase/database';
import { usersRef, movieRef, statsRef } from '../firebase';
import { Movie } from '../types';
import { Users, Eye, ThumbsUp, Activity, Film, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

export default function AnalyticsTab() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalUsers: 0,
    freeUsers: 0,
    premiumUsers: 0,
    guestVisits: 0,
    totalViews: 0,
    totalLikes: 0,
  });
  const [topMovies, setTopMovies] = useState<Movie[]>([]);

  useEffect(() => {
    setLoading(true);
    
    // Set up listeners for analytics data
    const unsubscribeUsers = onValue(usersRef, (snapshot) => {
      let total = 0;
      let free = 0;
      let premium = 0;
      
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          const user = child.val();
          if (user.email !== 'admin@moviebox.com') {
            total++;
            const isSubscribed = user.subscriptionExpiry && new Date(user.subscriptionExpiry) > new Date();
            if (user.status !== 'FREE' && isSubscribed) {
              premium++;
            } else {
              free++;
            }
          }
        });
      }
      
      setStats((prev) => ({
        ...prev,
        totalUsers: total,
        freeUsers: free,
        premiumUsers: premium,
      }));
    });

    const unsubscribeMovies = onValue(movieRef, (snapshot) => {
      let views = 0;
      let likes = 0;
      const moviesList: Movie[] = [];
      
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          const m = child.val() as Movie;
          views += m.viewCount || 0;
          likes += m.likeCount || 0;
          moviesList.push({ ...m, key: child.key || undefined });
        });
      }
      
      // Sort and pick top 10
      moviesList.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0));
      setTopMovies(moviesList.slice(0, 10));
      
      setStats((prev) => ({
        ...prev,
        totalViews: views,
        totalLikes: likes,
      }));
    });

    const unsubscribeStats = onValue(statsRef, (snapshot) => {
      const guestVisits = snapshot.exists() ? (snapshot.val().guestVisits || 0) : 0;
      setStats((prev) => ({
        ...prev,
        guestVisits,
      }));
      setLoading(false);
    });

    return () => {
      unsubscribeUsers();
      unsubscribeMovies();
      unsubscribeStats();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-gray-400 font-medium">Assembling live metrics...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Activity className="text-red-600 w-6 h-6 animate-pulse" /> Live Stats & Insights
        </h2>
        <p className="text-gray-400 text-sm mt-1">Real-time health indicator and engagement metrics of MovieBox.</p>
      </div>

      {/* Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }}
          className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Users className="w-24 h-24 text-red-600" />
          </div>
          <div className="flex items-center gap-3 text-red-500 font-medium text-sm mb-3">
            <Users className="w-4 h-4" /> User Database
          </div>
          <div className="text-4xl font-extrabold text-white tracking-tight">{stats.totalUsers}</div>
          <div className="mt-3 flex items-center gap-2 text-xs text-gray-400">
            <span className="px-2 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-amber-500 font-semibold">VIP: {stats.premiumUsers}</span>
            <span className="px-2 py-0.5 rounded bg-zinc-800 border border-zinc-700 font-medium">Free: {stats.freeUsers}</span>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Activity className="w-24 h-24 text-blue-500" />
          </div>
          <div className="flex items-center gap-3 text-blue-500 font-medium text-sm mb-3">
            <Activity className="w-4 h-4" /> Guest Sessions
          </div>
          <div className="text-4xl font-extrabold text-white tracking-tight">{stats.guestVisits}</div>
          <div className="mt-3 text-xs text-gray-400">
            Unauthenticated views and app launches
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Eye className="w-24 h-24 text-green-500" />
          </div>
          <div className="flex items-center gap-3 text-green-500 font-medium text-sm mb-3">
            <Eye className="w-4 h-4" /> Combined Streams
          </div>
          <div className="text-4xl font-extrabold text-white tracking-tight">{stats.totalViews}</div>
          <div className="mt-3 text-xs text-gray-400">
            Total playback views registered across catalog
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <ThumbsUp className="w-24 h-24 text-amber-500" />
          </div>
          <div className="flex items-center gap-3 text-amber-500 font-medium text-sm mb-3">
            <ThumbsUp className="w-4 h-4" /> Member Favorites
          </div>
          <div className="text-4xl font-extrabold text-white tracking-tight">{stats.totalLikes}</div>
          <div className="mt-3 text-xs text-gray-400">
            Total heart reactions saved across accounts
          </div>
        </motion.div>
      </div>

      {/* Top 10 viewed movies */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="text-red-500 w-5 h-5" /> Top 10 Most Streamed Titles
        </h3>
        {topMovies.length === 0 ? (
          <div className="text-gray-500 py-8 text-center text-sm">No streaming statistics recorded yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-gray-400 text-xs font-semibold uppercase tracking-wider">
                  <th className="pb-3 pl-4">Rank</th>
                  <th className="pb-3">Title</th>
                  <th className="pb-3">Year / Type</th>
                  <th className="pb-3 text-right pr-4">Metrics</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800 text-sm">
                {topMovies.map((movie, index) => (
                  <tr key={movie.key || index} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="py-3 pl-4 font-bold text-red-500 text-base">#{index + 1}</td>
                    <td className="py-3 flex items-center gap-3">
                      <img 
                        src={movie.poster || 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=100'} 
                        alt={movie.title} 
                        className="w-10 h-14 object-cover rounded shadow-md border border-zinc-800"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="font-semibold text-white">{movie.title}</div>
                        <div className="text-xs text-gray-400 capitalize">{movie.category}</div>
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="text-gray-300 font-medium">{movie.year || 'N/A'}</div>
                      <span className={`inline-block text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        movie.access === 'FREE' 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {movie.access}
                      </span>
                    </td>
                    <td className="py-3 text-right pr-4">
                      <div className="text-white font-medium flex items-center justify-end gap-3 text-xs">
                        <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5 text-green-400" /> {movie.viewCount || 0}</span>
                        <span className="flex items-center gap-1"><ThumbsUp className="w-3.5 h-3.5 text-amber-400" /> {movie.likeCount || 0}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
