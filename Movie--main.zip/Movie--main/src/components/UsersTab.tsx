import React, { useEffect, useState } from 'react';
import { onValue, update } from 'firebase/database';
import { usersRef, subscriptionsRef } from '../firebase';
import { User, SubscriptionPlans, SubscriptionPlan } from '../types';
import { Users, Search, Trash2, Edit2, ShieldAlert, Check, X, Calendar, Key } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function UsersTab() {
  const [users, setUsers] = useState<User[]>([]);
  const [plans, setPlans] = useState<SubscriptionPlans>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Editing state
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editStatus, setEditStatus] = useState('FREE');
  const [editExpiry, setEditExpiry] = useState('');

  useEffect(() => {
    setLoading(true);
    
    // Listen to plans
    const unsubscribePlans = onValue(subscriptionsRef, (snapshot) => {
      if (snapshot.exists()) {
        setPlans(snapshot.val());
      }
    });

    // Listen to users
    const unsubscribeUsers = onValue(usersRef, (snapshot) => {
      const list: User[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          const u = child.val();
          if (u.email !== 'admin@moviebox.com') {
            list.push({
              uid: child.key || undefined,
              ...u
            });
          }
        });
      }
      setUsers(list);
      setLoading(false);
    });

    return () => {
      unsubscribePlans();
      unsubscribeUsers();
    };
  }, []);

  const handleEditClick = (u: User) => {
    setEditingUser(u);
    setEditStatus(u.status || 'FREE');
    setEditExpiry(u.subscriptionExpiry || '');
  };

  const handleUpdateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || !editingUser.uid) return;

    let finalExpiry = editExpiry || null;

    // Calculate expiry date based on plan if blank
    if (!finalExpiry && editStatus !== 'FREE') {
      const selectedPlan = (Object.values(plans) as SubscriptionPlan[]).find(p => p.name === editStatus);
      if (selectedPlan) {
        const d = new Date();
        d.setDate(d.getDate() + selectedPlan.duration);
        finalExpiry = d.toISOString().split('T')[0];
      }
    } else if (editStatus === 'FREE') {
      finalExpiry = null;
    }

    const payload = {
      status: editStatus,
      subscriptionExpiry: finalExpiry
    };

    update(usersRef, { [editingUser.uid]: { ...editingUser, ...payload } }).then(() => {
      alert('User subscription metrics updated successfully!');
      setEditingUser(null);
    }).catch(err => {
      alert('Error updating user: ' + err.message);
    });
  };

  const handleDeleteUser = (uid: string, email: string) => {
    if (confirm(`Are you absolutely sure you want to delete user "${email}"? This action cannot be undone.`)) {
      update(usersRef, { [uid]: null }).then(() => {
        alert('User account deleted.');
      }).catch(err => alert('Error: ' + err.message));
    }
  };

  const filteredUsers = users.filter(u => 
    (u.email || '').toLowerCase().includes(search.toLowerCase()) ||
    (u.status || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Users className="text-red-500 w-6 h-6" /> User Management
          </h2>
          <p className="text-gray-400 text-sm mt-1">Audit active accounts, adjust subscription plans, extend expiry intervals or delete profiles.</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative w-full max-w-md">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input 
          type="text" 
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search members by email or status tier..."
          className="w-full bg-zinc-900 border border-zinc-800 focus:border-red-600 rounded-xl pl-10 pr-4 py-2.5 text-white text-sm outline-none transition-all"
        />
      </div>

      {/* User Table Grid */}
      {loading ? (
        <div className="text-center py-20 text-gray-400 text-sm">Synchronizing user lists...</div>
      ) : filteredUsers.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No registered application users matched.
        </div>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-gray-400 text-xs font-semibold uppercase tracking-wider bg-zinc-950/40">
                  <th className="py-4 px-6">Email / Identifier</th>
                  <th className="py-4 px-6">Status Level</th>
                  <th className="py-4 px-6">Access Term Expiration</th>
                  <th className="py-4 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800 text-sm">
                {filteredUsers.map((u) => {
                  const isExpired = u.subscriptionExpiry && new Date(u.subscriptionExpiry) < new Date();
                  return (
                    <tr key={u.uid} className="hover:bg-zinc-800/40 transition-colors">
                      <td className="py-4 px-6">
                        <div className="font-semibold text-white">{u.email}</div>
                        <div className="text-[10px] text-gray-500 font-mono mt-0.5">UID: {u.uid}</div>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-block text-[10px] font-extrabold px-2.5 py-0.5 rounded ${
                          u.status === 'FREE'
                            ? 'bg-zinc-850 text-gray-400 border border-zinc-700'
                            : isExpired
                            ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          {u.status || 'FREE'} {isExpired && '(Expired)'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-gray-300 font-medium font-mono text-xs">
                        {u.subscriptionExpiry ? (
                          <span className={isExpired ? 'text-red-400 font-semibold' : 'text-emerald-400'}>
                            {u.subscriptionExpiry}
                          </span>
                        ) : (
                          <span className="text-gray-500">Unlimited (Free Tier)</span>
                        )}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <div className="flex gap-2 justify-end">
                          <button 
                            onClick={() => handleEditClick(u)}
                            className="p-2 bg-zinc-850 hover:bg-zinc-800 text-white border border-zinc-700 rounded-lg transition-colors"
                            title="Edit Subscription Profile"
                          >
                            <Edit2 className="w-3.5 h-3.5 text-red-500" />
                          </button>
                          <button 
                            onClick={() => handleDeleteUser(u.uid!, u.email)}
                            className="p-2 bg-red-950/50 hover:bg-red-900/60 text-red-400 border border-red-900/30 rounded-lg transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Key className="text-red-500 w-5 h-5" /> Adjust User Account
                </h3>
                <button onClick={() => setEditingUser(null)} className="text-gray-400 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateUser} className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">User Email</label>
                  <input 
                    type="email" 
                    value={editingUser.email} 
                    className="w-full bg-zinc-950/60 border border-zinc-850 rounded-xl px-4 py-3 text-gray-400 text-sm cursor-not-allowed outline-none"
                    disabled
                  />
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Membership Status Tier</label>
                  <select 
                    value={editStatus} 
                    onChange={e => setEditStatus(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  >
                    <option value="FREE">FREE (Regular Base Tier)</option>
                    {(Object.values(plans) as SubscriptionPlan[]).map(p => (
                      <option key={p.name} value={p.name}>{p.name} Membership</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Custom Expiry Date</label>
                  <input 
                    type="date" 
                    value={editExpiry} 
                    onChange={e => setEditExpiry(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                  <small className="text-zinc-500 mt-1.5 block leading-normal">
                    Leave empty to automatically calculate the expiry limit based on the chosen plan duration (recommended). Set for FREE status to remove limits.
                  </small>
                </div>

                <div className="flex gap-3 pt-4 border-t border-zinc-800">
                  <button 
                    type="button" 
                    onClick={() => setEditingUser(null)}
                    className="flex-1 bg-zinc-850 hover:bg-zinc-800 text-white font-semibold py-3 rounded-xl transition-colors text-sm"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl transition-colors text-sm"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
