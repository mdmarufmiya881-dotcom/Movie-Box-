import React, { useEffect, useState } from 'react';
import { onValue, update } from 'firebase/database';
import { requestRef } from '../firebase';
import { MovieRequest } from '../types';
import { HelpCircle, Trash2, Calendar, User, Globe, MessageSquare } from 'lucide-react';
import { motion } from 'motion/react';

export default function MovieRequestsTab() {
  const [requests, setRequests] = useState<MovieRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(requestRef, (snapshot) => {
      const list: MovieRequest[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          list.push({
            key: child.key || undefined,
            ...child.val()
          });
        });
      }
      list.reverse(); // Newest first
      setRequests(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleDeleteRequest = (key: string, title: string) => {
    if (confirm(`Mark request for "${title}" as completed or delete it?`)) {
      update(requestRef, { [key]: null }).then(() => {
        alert('Request removed successfully.');
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <MessageSquare className="text-red-500 w-6 h-6" /> User Movie Requests
        </h2>
        <p className="text-gray-400 text-sm mt-1">Review, manage, and fulfill titles requested directly by application members.</p>
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-400 text-sm">Synchronizing user requests...</div>
      ) : requests.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No pending movie requests from users.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {requests.map((req) => (
            <div 
              key={req.key} 
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition-all flex justify-between items-start gap-4"
            >
              <div className="space-y-3 overflow-hidden">
                <div className="flex items-center gap-2 bg-red-950/40 text-red-400 border border-red-900/30 font-bold text-[10px] px-2.5 py-0.5 rounded-full w-fit uppercase">
                  Pending Request
                </div>
                
                <h3 className="font-bold text-white text-lg leading-snug truncate">{req.title}</h3>
                
                <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs text-gray-400">
                  <span className="flex items-center gap-1.5 truncate">
                    <Calendar className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    Year: {req.year || 'N/A'}
                  </span>
                  <span className="flex items-center gap-1.5 truncate">
                    <Globe className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    Language: {req.language || 'N/A'}
                  </span>
                  <span className="flex items-center gap-1.5 col-span-2 truncate">
                    <User className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    By: {req.requestedBy || 'Anonymous'}
                  </span>
                </div>
                
                {req.timestamp && (
                  <p className="text-[10px] text-gray-500 font-mono">
                    Logged: {new Date(req.timestamp).toLocaleString()}
                  </p>
                )}
              </div>

              <button 
                onClick={() => handleDeleteRequest(req.key!, req.title)}
                className="bg-red-950/60 hover:bg-red-900 text-red-400 text-xs font-semibold p-2.5 rounded-xl transition-all border border-red-900/30 shrink-0"
                title="Mark as Fufilled/Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
