import React, { useEffect, useState } from 'react';
import { onValue, push, update } from 'firebase/database';
import { codeRef } from '../firebase';
import { DevCode } from '../types';
import { Code, Trash2, Edit2, Plus, X, Check, Image, Sliders, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function CodesTab() {
  const [codes, setCodes] = useState<DevCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  
  // Form values
  const [editingCode, setEditingCode] = useState<DevCode | null>(null);
  const [formData, setFormData] = useState<Partial<DevCode>>({
    name: '',
    icon: '',
    category: '',
    details: '',
    screenshots: ['', ''],
    downloadLink: '',
    contactLink: ''
  });

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(codeRef, (snapshot) => {
      const list: DevCode[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          list.push({
            key: child.key || undefined,
            ...child.val()
          });
        });
      }
      list.reverse();
      setCodes(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleEditClick = (code: DevCode) => {
    setEditingCode(code);
    setFormData({
      name: code.name || '',
      icon: code.icon || '',
      category: code.category || '',
      details: code.details || '',
      screenshots: [code.screenshots?.[0] || '', code.screenshots?.[1] || ''],
      downloadLink: code.downloadLink || '',
      contactLink: code.contactLink || ''
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.downloadLink) {
      alert('Code name and download URL are absolutely required.');
      return;
    }

    const payload: Omit<DevCode, 'key'> = {
      name: formData.name,
      icon: formData.icon || '',
      category: formData.category || 'HTML/CSS/JS',
      details: formData.details || '',
      screenshots: (formData.screenshots || []).filter(Boolean),
      downloadLink: formData.downloadLink,
      contactLink: formData.contactLink || '',
      timestamp: Date.now()
    };

    if (editingCode && editingCode.key) {
      update(codeRef, { [editingCode.key]: payload }).then(() => {
        alert('Developer Code item updated!');
        resetForm();
      }).catch(err => alert('Error: ' + err.message));
    } else {
      push(codeRef, payload).then(() => {
        alert('Developer Code saved to repository!');
        resetForm();
      }).catch(err => alert('Error: ' + err.message));
    }
  };

  const handleDeleteCode = (key: string, name: string) => {
    if (confirm(`Are you absolutely sure you want to delete "${name}" from the repository?`)) {
      update(codeRef, { [key]: null }).then(() => {
        alert('Deleted!');
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      icon: '',
      category: '',
      details: '',
      screenshots: ['', ''],
      downloadLink: '',
      contactLink: ''
    });
    setEditingCode(null);
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Code className="text-red-500 w-6 h-6" /> Developer Code Repository
          </h2>
          <p className="text-gray-400 text-sm mt-1">Provide premium, download-ready templates, UI libraries and scripts for coder users.</p>
        </div>
        <button 
          onClick={() => {
            if (showForm) resetForm();
            else setShowForm(true);
          }}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-all shadow-lg text-sm"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? 'Close Panel' : 'Upload Project'}
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.form 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleFormSubmit}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden"
          >
            <div className="space-y-4">
              <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                <Sliders className="w-4 h-4" /> Code Parameters
              </h3>
              
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Project Name *</label>
                <input 
                  type="text" 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g. Modern Cinema Login Page Layout"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Framework/Language</label>
                  <input 
                    type="text" 
                    value={formData.category} 
                    onChange={e => setFormData({...formData, category: e.target.value})}
                    placeholder="e.g. React Native, HTML5, Python"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Icon Image URL</label>
                  <input 
                    type="text" 
                    value={formData.icon} 
                    onChange={e => setFormData({...formData, icon: e.target.value})}
                    placeholder="https://example.com/icon.png"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Project Description & Details</label>
                <textarea 
                  value={formData.details} 
                  onChange={e => setFormData({...formData, details: e.target.value})}
                  placeholder="Summarize key attributes, installation instructions or custom features..."
                  rows={4}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all resize-none"
                />
              </div>
            </div>

            <div className="space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                  <Image className="w-4 h-4" /> assets & distribution
                </h3>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Download Zip/Source Link *</label>
                    <input 
                      type="text" 
                      value={formData.downloadLink} 
                      onChange={e => setFormData({...formData, downloadLink: e.target.value})}
                      placeholder="Google Drive, Dropbox, Github Zip URL"
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Support/Contact Link</label>
                    <input 
                      type="text" 
                      value={formData.contactLink} 
                      onChange={e => setFormData({...formData, contactLink: e.target.value})}
                      placeholder="Telegram, Discord support URL"
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Screenshot URL 1</label>
                    <input 
                      type="text" 
                      value={formData.screenshots?.[0] || ''} 
                      onChange={e => {
                        const ss = [...(formData.screenshots || ['', ''])];
                        ss[0] = e.target.value;
                        setFormData({...formData, screenshots: ss});
                      }}
                      placeholder="Preview URL 1"
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Screenshot URL 2</label>
                    <input 
                      type="text" 
                      value={formData.screenshots?.[1] || ''} 
                      onChange={e => {
                        const ss = [...(formData.screenshots || ['', ''])];
                        ss[1] = e.target.value;
                        setFormData({...formData, screenshots: ss});
                      }}
                      placeholder="Preview URL 2"
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                {editingCode && (
                  <button 
                    type="button"
                    onClick={resetForm}
                    className="flex-1 bg-zinc-800 hover:bg-zinc-750 text-white font-bold py-3.5 rounded-xl transition-all cursor-pointer text-sm"
                  >
                    Cancel Edit
                  </button>
                )}
                <button 
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md cursor-pointer text-sm"
                >
                  <Check className="w-5 h-5" /> {editingCode ? 'Apply Code Edit' : 'Commit Code Upload'}
                </button>
              </div>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Code Repository list */}
      {loading ? (
        <div className="text-center py-10 text-gray-400 text-sm">Synchronizing developer templates...</div>
      ) : codes.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No developer source code items uploaded.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {codes.map((code) => (
            <div key={code.key} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 flex gap-4 hover:border-zinc-700 transition-all items-start justify-between">
              <div className="flex gap-4 items-start overflow-hidden">
                <div className="w-14 h-14 bg-zinc-950 border border-zinc-850 rounded-2xl flex items-center justify-center shrink-0 overflow-hidden text-red-500 font-bold p-1">
                  {code.icon ? (
                    <img src={code.icon} alt={code.name} className="w-full h-full object-contain" onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/100' }} />
                  ) : (
                    <Code className="w-7 h-7" />
                  )}
                </div>
                <div className="overflow-hidden">
                  <h4 className="font-bold text-white text-base leading-tight truncate">{code.name}</h4>
                  <div className="text-xs text-red-400 font-semibold mt-1 uppercase tracking-wide">{code.category}</div>
                  {code.details && (
                    <p className="text-xs text-gray-400 mt-2 line-clamp-2 leading-relaxed">{code.details}</p>
                  )}
                  {code.downloadLink && (
                    <a 
                      href={code.downloadLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-zinc-500 hover:text-white transition-colors mt-3 font-mono"
                    >
                      Sources ZIP Link <ArrowUpRight className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-2 shrink-0">
                <button 
                  onClick={() => handleEditClick(code)}
                  className="p-2 bg-zinc-800 hover:bg-zinc-750 text-white rounded-xl border border-zinc-700 transition-all text-xs flex justify-center items-center"
                  title="Edit Code Profile"
                >
                  <Edit2 className="w-4 h-4 text-red-500" />
                </button>
                <button 
                  onClick={() => handleDeleteCode(code.key!, code.name)}
                  className="p-2 bg-red-950/60 hover:bg-red-900 text-red-400 rounded-xl border border-red-900/30 transition-all text-xs flex justify-center items-center"
                  title="Delete Item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
