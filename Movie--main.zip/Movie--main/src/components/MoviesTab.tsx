import React, { useEffect, useState } from 'react';
import { onValue, push, remove, update } from 'firebase/database';
import { movieRef } from '../firebase';
import { Movie } from '../types';
import { Search, Plus, Trash2, Edit2, Film, Check, X, Filter, Sliders, Image, Star, Eye, ThumbsUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function MoviesTab() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [accessFilter, setAccessFilter] = useState<string>('all');
  
  // Create state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMovie, setNewMovie] = useState<Partial<Movie>>({
    title: '',
    poster: '',
    backdrop: '',
    year: '',
    rating: '',
    storyline: '',
    access: 'FREE',
    language: '',
    movieLink: '',
    screenshots: ['', ''],
    category: 'Hollywood'
  });

  // Edit State
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(movieRef, (snapshot) => {
      const list: Movie[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          list.push({
            key: child.key || undefined,
            ...child.val()
          });
        });
      }
      list.reverse(); // Newest first
      setMovies(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddMovie = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMovie.title || !newMovie.poster) {
      alert('Movie Title and Poster URL are absolutely required.');
      return;
    }

    const payload: Omit<Movie, 'key'> = {
      title: newMovie.title,
      poster: newMovie.poster,
      backdrop: newMovie.backdrop || '',
      year: newMovie.year || '',
      rating: newMovie.rating || 'N/A',
      storyline: newMovie.storyline || '',
      access: newMovie.access || 'FREE',
      language: newMovie.language || '',
      movieLink: newMovie.movieLink || '',
      screenshots: (newMovie.screenshots || []).filter(Boolean),
      category: newMovie.category as 'Hollywood' | 'Bollywood' | 'South Indian',
      likeCount: 0,
      viewCount: 0,
      timestamp: Date.now()
    };

    push(movieRef, payload).then(() => {
      alert('Movie successfully added to catalog!');
      setNewMovie({
        title: '',
        poster: '',
        backdrop: '',
        year: '',
        rating: '',
        storyline: '',
        access: 'FREE',
        language: '',
        movieLink: '',
        screenshots: ['', ''],
        category: 'Hollywood'
      });
      setShowAddForm(false);
    }).catch(err => {
      alert('Error saving movie: ' + err.message);
    });
  };

  const handleUpdateMovie = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMovie || !editingMovie.key) return;

    const { key, ...cleanPayload } = editingMovie;

    update(movieRef, { [key]: { ...cleanPayload } }).then(() => {
      alert('Movie catalog item updated successfully!');
      setEditingMovie(null);
    }).catch(err => {
      alert('Error updating movie: ' + err.message);
    });
  };

  const handleDeleteMovie = (key: string, title: string) => {
    if (confirm(`Are you absolutely sure you want to delete "${title}" from the catalog? This action is irreversible.`)) {
      remove(movieRef).then(() => {
        // Note: Standard Firebase v10 syntax to delete single child:
        // standard database update or path reference. To delete a specific key:
        // we can use standard update/remove or import ref and delete child.
        // Wait, since we can update the node or push, let's look at how the HTML did it:
        // movieRef.child(key).remove()
        // In Modular SDK:
        // remove(ref(db, `movie/${key}`))
        // We imported the `db` instance in `../firebase.ts`. Let's create a child reference or use standard updates.
        // Wait, let's verify if we can do this directly or use `update(movieRef, { [key]: null })` which deletes the node in Firebase!
        // YES! `update(movieRef, { [key]: null })` is elegant, generic, and perfectly robust for both Realtime DB and works directly with `movieRef` without needing sub-refs.
        update(movieRef, { [key]: null }).then(() => {
          alert(`"${title}" has been deleted.`);
        });
      });
    }
  };

  const filteredMovies = movies.filter(m => {
    const matchesSearch = (m.title || '').toLowerCase().includes(search.toLowerCase()) || 
                          (m.language || '').toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || m.category === categoryFilter;
    const matchesAccess = accessFilter === 'all' || m.access === accessFilter;
    return matchesSearch && matchesCategory && matchesAccess;
  });

  return (
    <div className="space-y-6">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Film className="text-red-500 w-6 h-6" /> Movies Catalog
          </h2>
          <p className="text-gray-400 text-sm mt-1">Manage, edit, search and populate movies stored in the system database.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-all shadow-lg shadow-red-600/10 text-sm"
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Cancel Form' : 'Add Movie'}
        </button>
      </div>

      {/* Add Movie Section */}
      <AnimatePresence>
        {showAddForm && (
          <motion.form 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleAddMovie}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden"
          >
            <div className="space-y-4">
              <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                <Sliders className="w-4 h-4" /> Primary Meta Info
              </h3>
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Movie Title *</label>
                <input 
                  type="text" 
                  value={newMovie.title} 
                  onChange={e => setNewMovie({...newMovie, title: e.target.value})}
                  placeholder="Enter complete movie title"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Release Year</label>
                  <input 
                    type="number" 
                    value={newMovie.year} 
                    onChange={e => setNewMovie({...newMovie, year: e.target.value})}
                    placeholder="e.g. 2026"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Rating (IMDb)</label>
                  <input 
                    type="text" 
                    value={newMovie.rating} 
                    onChange={e => setNewMovie({...newMovie, rating: e.target.value})}
                    placeholder="e.g. 8.5"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Language</label>
                <input 
                  type="text" 
                  value={newMovie.language} 
                  onChange={e => setNewMovie({...newMovie, language: e.target.value})}
                  placeholder="e.g. English, Hindi, Tamil"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Storyline Summary</label>
                <textarea 
                  value={newMovie.storyline} 
                  onChange={e => setNewMovie({...newMovie, storyline: e.target.value})}
                  placeholder="Brief synopsis of the film..."
                  rows={4}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all resize-none"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-md font-bold text-red-500 border-b border-zinc-800 pb-2 flex items-center gap-2">
                <Image className="w-4 h-4" /> media, categories, & stream urls
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Region Category</label>
                  <select 
                    value={newMovie.category} 
                    onChange={e => setNewMovie({...newMovie, category: e.target.value as any})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  >
                    <option value="Hollywood">Hollywood</option>
                    <option value="Bollywood">Bollywood</option>
                    <option value="South Indian">South Indian</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Access Tier</label>
                  <select 
                    value={newMovie.access} 
                    onChange={e => setNewMovie({...newMovie, access: e.target.value as any})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  >
                    <option value="FREE">FREE</option>
                    <option value="VIP">VIP (Subscribers)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Poster Image URL *</label>
                <input 
                  type="text" 
                  value={newMovie.poster} 
                  onChange={e => setNewMovie({...newMovie, poster: e.target.value})}
                  placeholder="https://example.com/poster.jpg"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Slider Banner Image URL</label>
                <input 
                  type="text" 
                  value={newMovie.backdrop} 
                  onChange={e => setNewMovie({...newMovie, backdrop: e.target.value})}
                  placeholder="https://example.com/banner.jpg"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Primary Stream/Movie Link</label>
                <input 
                  type="text" 
                  value={newMovie.movieLink} 
                  onChange={e => setNewMovie({...newMovie, movieLink: e.target.value})}
                  placeholder="m3u8, mp4, gdrive link or direct embed stream URL"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Screenshot URL 1</label>
                  <input 
                    type="text" 
                    value={newMovie.screenshots?.[0] || ''} 
                    onChange={e => {
                      const ss = [...(newMovie.screenshots || ['', ''])];
                      ss[0] = e.target.value;
                      setNewMovie({...newMovie, screenshots: ss});
                    }}
                    placeholder="Screenshot URL 1"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Screenshot URL 2</label>
                  <input 
                    type="text" 
                    value={newMovie.screenshots?.[1] || ''} 
                    onChange={e => {
                      const ss = [...(newMovie.screenshots || ['', ''])];
                      ss[1] = e.target.value;
                      setNewMovie({...newMovie, screenshots: ss});
                    }}
                    placeholder="Screenshot URL 2"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md mt-6 cursor-pointer text-sm"
              >
                <Check className="w-5 h-5" /> Save New Movie to DB
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Filter and Search Bar */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input 
            type="text" 
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search catalog by title, language..."
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl pl-10 pr-4 py-2.5 text-white text-sm outline-none transition-all"
          />
        </div>
        
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 text-xs text-gray-400 font-semibold uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5" /> Filter by:
          </div>
          <select 
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-red-600 transition-all"
          >
            <option value="all">All Regions</option>
            <option value="Hollywood">Hollywood</option>
            <option value="Bollywood">Bollywood</option>
            <option value="South Indian">South Indian</option>
          </select>

          <select 
            value={accessFilter}
            onChange={e => setAccessFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-red-600 transition-all"
          >
            <option value="all">All Access</option>
            <option value="FREE">FREE</option>
            <option value="VIP">VIP</option>
          </select>
        </div>
      </div>

      {/* Movie Grid List */}
      {loading ? (
        <div className="text-center py-20 text-gray-400 text-sm font-medium">Loading catalog items...</div>
      ) : filteredMovies.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No catalog movies matching your search filters.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMovies.map((movie) => (
            <div key={movie.key} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden group hover:border-zinc-700 transition-all flex flex-col justify-between">
              <div>
                <div className="relative aspect-video w-full bg-zinc-950 overflow-hidden">
                  <img 
                    src={movie.backdrop || movie.poster || 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400'} 
                    alt={movie.title}
                    className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-550"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent"></div>
                  
                  {/* Absolute Badge */}
                  <span className={`absolute top-3 left-3 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    movie.access === 'FREE' 
                      ? 'bg-emerald-500 text-white' 
                      : 'bg-amber-500 text-black'
                  }`}>
                    {movie.access}
                  </span>

                  {movie.rating && (
                    <span className="absolute bottom-3 right-3 bg-zinc-900/90 text-yellow-400 border border-zinc-700 font-bold text-xs px-2 py-1 rounded-lg flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" /> {movie.rating}
                    </span>
                  )}
                </div>

                <div className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-white text-base leading-tight group-hover:text-red-500 transition-colors line-clamp-1">{movie.title}</h4>
                      <div className="text-xs text-gray-400 mt-1 flex items-center gap-2">
                        <span>{movie.category}</span>
                        <span>•</span>
                        <span>{movie.year || 'N/A'}</span>
                        {movie.language && (
                          <>
                            <span>•</span>
                            <span className="line-clamp-1 max-w-[80px]">{movie.language}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {movie.storyline && (
                    <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed h-8">{movie.storyline}</p>
                  )}

                  <div className="text-xs text-zinc-500 flex items-center gap-4 pt-1">
                    <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {movie.viewCount || 0} views</span>
                    <span className="flex items-center gap-1"><ThumbsUp className="w-3.5 h-3.5" /> {movie.likeCount || 0} favorites</span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-5 pt-0 border-t border-zinc-850 flex gap-2">
                <button 
                  onClick={() => setEditingMovie(movie)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-zinc-800 hover:bg-zinc-750 text-white text-xs font-semibold py-2 px-3 rounded-xl transition-all border border-zinc-700"
                >
                  <Edit2 className="w-3.5 h-3.5" /> Edit Movie
                </button>
                <button 
                  onClick={() => handleDeleteMovie(movie.key!, movie.title)}
                  className="bg-red-950 hover:bg-red-900 text-red-400 text-xs font-semibold p-2 rounded-xl transition-all border border-red-900/40"
                  title="Delete Movie"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Movie Modal */}
      <AnimatePresence>
        {editingMovie && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Edit2 className="text-red-500 w-5 h-5" /> Edit Catalog Item
                </h3>
                <button onClick={() => setEditingMovie(null)} className="text-gray-400 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateMovie} className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Title</label>
                  <input 
                    type="text" 
                    value={editingMovie.title} 
                    onChange={e => setEditingMovie({...editingMovie, title: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Region Category</label>
                    <select 
                      value={editingMovie.category} 
                      onChange={e => setEditingMovie({...editingMovie, category: e.target.value as any})}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    >
                      <option value="Hollywood">Hollywood</option>
                      <option value="Bollywood">Bollywood</option>
                      <option value="South Indian">South Indian</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Access Tier</label>
                    <select 
                      value={editingMovie.access} 
                      onChange={e => setEditingMovie({...editingMovie, access: e.target.value as any})}
                      className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    >
                      <option value="FREE">FREE</option>
                      <option value="VIP">VIP</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Primary Stream Link</label>
                  <input 
                    type="text" 
                    value={editingMovie.movieLink || ''} 
                    onChange={e => setEditingMovie({...editingMovie, movieLink: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    placeholder="Streaming URL"
                  />
                </div>

                <div>
                  <label className="block text-xs text-gray-400 font-semibold mb-1 uppercase">Rating (IMDb)</label>
                  <input 
                    type="text" 
                    value={editingMovie.rating || ''} 
                    onChange={e => setEditingMovie({...editingMovie, rating: e.target.value})}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                    placeholder="e.g. 8.5"
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t border-zinc-800">
                  <button 
                    type="button" 
                    onClick={() => setEditingMovie(null)}
                    className="flex-1 bg-zinc-800 hover:bg-zinc-750 text-white font-semibold py-3 rounded-xl transition-all text-sm cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl transition-all text-sm cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
