import React, { useEffect, useState } from 'react';
import { onValue, push, remove, update } from 'firebase/database';
import { upcomingMovieRef } from '../firebase';
import { UpcomingMovie } from '../types';
import { Trash2, Calendar, Plus, X, Check, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function UpcomingTab() {
  const [upcoming, setUpcoming] = useState<UpcomingMovie[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  
  // New release forms
  const [title, setTitle] = useState('');
  const [poster, setPoster] = useState('');
  const [releaseDate, setReleaseDate] = useState('');

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onValue(upcomingMovieRef, (snapshot) => {
      const list: UpcomingMovie[] = [];
      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          list.push({
            key: child.key || undefined,
            ...child.val()
          });
        });
      }
      list.reverse();
      setUpcoming(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddUpcoming = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !poster || !releaseDate) {
      alert('Please fill out all fields for the upcoming title.');
      return;
    }

    const payload: Omit<UpcomingMovie, 'key'> = {
      title,
      poster,
      releaseDate,
      timestamp: Date.now()
    };

    push(upcomingMovieRef, payload).then(() => {
      alert('Upcoming movie scheduled!');
      setTitle('');
      setPoster('');
      setReleaseDate('');
      setShowAddForm(false);
    }).catch(err => {
      alert('Error: ' + err.message);
    });
  };

  const handleDeleteUpcoming = (key: string, movieTitle: string) => {
    if (confirm(`Are you sure you want to remove "${movieTitle}"?`)) {
      update(upcomingMovieRef, { [key]: null }).then(() => {
        alert('Deleted!');
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Calendar className="text-red-500 w-6 h-6" /> Upcoming Releases
          </h2>
          <p className="text-gray-400 text-sm mt-1">Schedule and manage teaser cards for high-anticipation coming attraction movies.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-all shadow-lg text-sm"
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Close Panel' : 'Schedule Teaser'}
        </button>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.form 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleAddUpcoming}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden"
          >
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Movie Title *</label>
                <input 
                  type="text" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Avatar: Fire and Ash"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Anticipated Release Date *</label>
                <input 
                  type="date" 
                  value={releaseDate} 
                  onChange={e => setReleaseDate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div className="space-y-4 flex flex-col justify-between">
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Poster Image URL *</label>
                <input 
                  type="text" 
                  value={poster} 
                  onChange={e => setPoster(e.target.value)}
                  placeholder="https://example.com/teaser_poster.jpg"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                  required
                />
              </div>

              <button 
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md mt-6 cursor-pointer text-sm"
              >
                <Check className="w-5 h-5" /> Schedule Teaser Release
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Release List */}
      {loading ? (
        <div className="text-center py-10 text-gray-400 text-sm">Synchronizing schedule...</div>
      ) : upcoming.length === 0 ? (
        <div className="bg-zinc-900/40 border border-dashed border-zinc-800 py-16 text-center rounded-2xl text-gray-500 text-sm">
          No upcoming scheduled teasers found.
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {upcoming.map((movie) => {
            const daysLeft = Math.ceil((new Date(movie.releaseDate).getTime() - Date.now()) / (1000 * 3600 * 24));
            return (
              <div key={movie.key} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden group hover:border-zinc-700 transition-all flex flex-col justify-between">
                <div className="relative aspect-[2/3] bg-zinc-950 overflow-hidden">
                  <img 
                    src={movie.poster} 
                    alt={movie.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-550"
                    referrerPolicy="no-referrer"
                    onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=200' }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-900/40 to-transparent"></div>
                  
                  {/* Absolute Badge */}
                  <span className="absolute top-3 left-3 bg-red-600 text-white font-bold text-[9px] px-2 py-0.5 rounded-md uppercase flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {daysLeft > 0 ? `${daysLeft} Days Left` : 'Released'}
                  </span>
                </div>

                <div className="p-4 space-y-3">
                  <h4 className="font-bold text-white text-sm line-clamp-1">{movie.title}</h4>
                  <p className="text-xs text-gray-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-red-500" /> Releases: {new Date(movie.releaseDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                  </p>
                  
                  <button 
                    onClick={() => handleDeleteUpcoming(movie.key!, movie.title)}
                    className="w-full flex items-center justify-center gap-1.5 bg-red-950/40 hover:bg-red-900/60 text-red-400 text-xs font-semibold py-2 rounded-xl transition-all border border-red-900/30"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Remove Scheduled
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
