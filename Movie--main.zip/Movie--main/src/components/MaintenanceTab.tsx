import React, { useEffect, useState } from 'react';
import { onValue, set } from 'firebase/database';
import { maintenanceRef, appDownloadRef, tvWebRef } from '../firebase';
import { MaintenanceSettings, AppDownload, TvWeb } from '../types';
import { Settings, ShieldAlert, Download, Tv, CheckCircle, Radio, Link } from 'lucide-react';
import { motion } from 'motion/react';

export default function MaintenanceTab() {
  const [maintenance, setMaintenance] = useState<MaintenanceSettings>({
    status: 'off',
    notice: '',
    contactLink: ''
  });
  const [appDownload, setAppDownload] = useState<AppDownload>({
    link: '',
    version: '',
    status: 'on'
  });
  const [tvWeb, setTvWeb] = useState<TvWeb>({
    link: '',
    status: 'off'
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    
    // Listen to maintenance
    const unsubscribeMaintenance = onValue(maintenanceRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setMaintenance({
          status: val.status || 'off',
          notice: val.notice || '',
          contactLink: val.contactLink || ''
        });
      }
    });

    // Listen to appDownload
    const unsubscribeAppDownload = onValue(appDownloadRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setAppDownload({
          link: val.link || '',
          version: val.version || '',
          status: val.status || 'on'
        });
      }
    });

    // Listen to tvWeb
    const unsubscribeTvWeb = onValue(tvWebRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setTvWeb({
          link: val.link || '',
          status: val.status || 'off'
        });
      }
    });

    setLoading(false);

    return () => {
      unsubscribeMaintenance();
      unsubscribeAppDownload();
      unsubscribeTvWeb();
    };
  }, []);

  const handleSaveMaintenance = (e: React.FormEvent) => {
    e.preventDefault();
    set(maintenanceRef, maintenance).then(() => {
      alert('Maintenance mode configuration applied!');
    }).catch(err => alert('Error: ' + err.message));
  };

  const handleSaveAppDownload = (e: React.FormEvent) => {
    e.preventDefault();
    set(appDownloadRef, appDownload).then(() => {
      alert('Mobile Application package details applied!');
    }).catch(err => alert('Error: ' + err.message));
  };

  const handleSaveTvWeb = (e: React.FormEvent) => {
    e.preventDefault();
    set(tvWebRef, tvWeb).then(() => {
      alert('TV Web link preferences applied!');
    }).catch(err => alert('Error: ' + err.message));
  };

  if (loading) {
    return (
      <div className="text-center py-20 text-gray-400 text-sm">Synchronizing config models...</div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Settings className="text-red-500 w-6 h-6" /> System Configuration Control Center
        </h2>
        <p className="text-gray-400 text-sm mt-1">Configure maintenance states, direct mobile application deployment download versions, and TV section routing.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Maintenance Config */}
        <form onSubmit={handleSaveMaintenance} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5">
          <h3 className="text-md font-bold text-white border-b border-zinc-850 pb-2 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-500" /> Server Maintenance Mode
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">State Option</label>
              <select 
                value={maintenance.status} 
                onChange={e => setMaintenance({ ...maintenance, status: e.target.value as any })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
              >
                <option value="off">OFF (Online & Live)</option>
                <option value="on">ON (Lock Client Requests - Under Maintenance)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Notice Text Presented to Client</label>
              <textarea 
                value={maintenance.notice} 
                onChange={e => setMaintenance({ ...maintenance, notice: e.target.value })}
                placeholder="e.g. Server under maintenance. We will be back shortly."
                rows={4}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all resize-none"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Telegram / Admin Support Handle URL</label>
              <input 
                type="text" 
                value={maintenance.contactLink} 
                onChange={e => setMaintenance({ ...maintenance, contactLink: e.target.value })}
                placeholder="https://t.me/your_username"
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md cursor-pointer text-sm"
          >
            <CheckCircle className="w-4 h-4" /> Save Maintenance Rules
          </button>
        </form>

        {/* Mobile App & TV Web Routing */}
        <div className="space-y-8">
          {/* Mobile App Downloads */}
          <form onSubmit={handleSaveAppDownload} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5">
            <h3 className="text-md font-bold text-white border-b border-zinc-850 pb-2 flex items-center gap-2">
              <Download className="w-4 h-4 text-red-500" /> APK Package Settings
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Application Distribution Version</label>
                <input 
                  type="text" 
                  value={appDownload.version} 
                  onChange={e => setAppDownload({ ...appDownload, version: e.target.value })}
                  placeholder="e.g. v2.4.1"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Direct Package Download Link (.apk)</label>
                <input 
                  type="text" 
                  value={appDownload.link} 
                  onChange={e => setAppDownload({ ...appDownload, link: e.target.value })}
                  placeholder="Google Drive, Github Asset URL"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md cursor-pointer text-sm"
            >
              <CheckCircle className="w-4 h-4" /> Save App Version Details
            </button>
          </form>

          {/* TV Section Routing */}
          <form onSubmit={handleSaveTvWeb} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-5">
            <h3 className="text-md font-bold text-white border-b border-zinc-850 pb-2 flex items-center gap-2">
              <Tv className="w-4 h-4 text-red-500" /> TV Section Redirect Setup
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Tv Section Redirection URL</label>
                <input 
                  type="text" 
                  value={tvWeb.link} 
                  onChange={e => setTvWeb({ ...tvWeb, link: e.target.value })}
                  placeholder="Link to external TV web frame"
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all font-mono"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 font-semibold mb-1.5 uppercase tracking-wider">Routing Mode</label>
                <select 
                  value={tvWeb.status} 
                  onChange={e => setTvWeb({ ...tvWeb, status: e.target.value as any })}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 rounded-xl px-4 py-3 text-white text-sm outline-none transition-all"
                >
                  <option value="off">OFF (Use Local liveTv database node streams)</option>
                  <option value="on">ON (Redirect TV Section clicks to the TV URL above)</option>
                </select>
              </div>
            </div>

            <button 
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md cursor-pointer text-sm"
            >
              <CheckCircle className="w-4 h-4" /> Apply TV Redirection rules
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
